function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5hJG8g5fsyV":
        Script1();
        break;
      case "6M4VBCaCZH8":
        Script2();
        break;
      case "69LPkfZMfbs":
        Script3();
        break;
      case "6qaUvw9oHqI":
        Script4();
        break;
      case "5jYS4RC6qyI":
        Script5();
        break;
      case "6QZMf1O0Wul":
        Script6();
        break;
      case "6rgYL8TS0zs":
        Script7();
        break;
      case "6mSp9A0NR7U":
        Script8();
        break;
      case "5WZdQrvnD30":
        Script9();
        break;
      case "67O0PO4xRjV":
        Script10();
        break;
      case "686e1jnAjAf":
        Script11();
        break;
      case "5b0QYZVy2hr":
        Script12();
        break;
      case "6JhP8sVH0OL":
        Script13();
        break;
      case "619sbMUwy4a":
        Script14();
        break;
      case "6etCD3ZvhSQ":
        Script15();
        break;
      case "6TwyT766Ed8":
        Script16();
        break;
      case "5ZDFCDe4fhx":
        Script17();
        break;
      case "6ISfHqWZtLl":
        Script18();
        break;
      case "6CL8qwAptma":
        Script19();
        break;
      case "5l6hJDEBOYt":
        Script20();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
};
