window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script1 = function()
{
  window.flapDefaults = {
    width: 120, height: 168, radius: 4,
    colorTop: "#596064", colorBot: "#212326", textColor: "#ffffff",
    fontSize: 140, fontFamily: "'IBM Plex Mono', monospace, sans-serif",
    elements: ["0", "1"], initialChar: "0"
};
window.flapConfigs = [
    { accName: "SplitFlap0", variableName: "Flap0_State" },
    { accName: "SplitFlap1", variableName: "Flap1_State" },
    { accName: "SplitFlap2", variableName: "Flap2_State" },
    { accName: "SplitFlap3", variableName: "Flap3_State" },
    { accName: "SplitFlap4", variableName: "Flap4_State" },
    { accName: "SplitFlap5", variableName: "Flap5_State" },
    { accName: "SplitFlap6", variableName: "Flap6_State" },
    { accName: "SplitFlap7", variableName: "Flap7_State" }
];
window.splitFlaps = {}; 
window.flapConfigs.forEach(customConfig => {
    const config = Object.assign({}, window.flapDefaults, customConfig);
    const container = document.querySelector(`[data-acc-text="${config.accName}"]`);
    if (!container) return;
    const midY = config.height / 2;
    const seamY = midY - 2.5; 
    const svgContent = `
    <div class="split-flap-container" style="position: relative; width: 100%; height: 100%; perspective: 1000px;">
      <div class="face pt" style="position: absolute; left: 0; top: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; top:0;">
          <rect x="0" y="0" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorTop}"/>
          <text class="char-pt" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face ft" style="position: absolute; left: 0; top: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; top:0;">
          <rect x="0" y="0" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorTop}"/>
          <text class="char-ft" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face pb" style="position: absolute; left: 0; bottom: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; bottom:0;">
          <rect x="0" y="${midY}" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorBot}"/>
          <text class="char-pb" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face fb" style="position: absolute; left: 0; bottom: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; bottom:0;">
          <rect x="0" y="${midY}" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorBot}"/>
          <text class="char-fb" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
    </div>
    `;
    container.innerHTML = svgContent;
    let startIdx = config.elements.indexOf(config.initialChar);
    if (startIdx === -1) startIdx = 0;
    
    window.splitFlaps[config.accName] = {
        config: config, currentIndex: startIdx,
        textPt: container.querySelector('.char-pt'), textPb: container.querySelector('.char-pb'),
        textFt: container.querySelector('.char-ft'), textFb: container.querySelector('.char-fb'),
        flapTopD: container.querySelector('.ft'), flapBotD: container.querySelector('.fb')
    };
    const f = window.splitFlaps[config.accName];
    gsap.set(f.flapTopD, { transformOrigin: '50% 100%', backfaceVisibility: 'hidden', rotationX: 0 });
    gsap.set(f.flapBotD, { transformOrigin: '50% 0%', backfaceVisibility: 'hidden', rotationX: 90 });
    
    let startChar = config.elements[startIdx];
    f.textPt.textContent = startChar; f.textPb.textContent = startChar;
    f.textFt.textContent = startChar; f.textFb.textContent = startChar;
    
    if (typeof GetPlayer !== "undefined") {
        GetPlayer().SetVar(config.variableName, startChar);
    }
});
}

window.Script2 = function()
{
  // 1. Define the correct answers for this specific slide!
const correctAnswers = {
    "SplitFlap0": "0",
    "SplitFlap1": "1",
    "SplitFlap2": "1",
    "SplitFlap3": "1",
    "SplitFlap4": "0",
    "SplitFlap5": "1",
    "SplitFlap6": "1",
    "SplitFlap7": "0"
};

let passed = true;

window.flapConfigs.forEach(config => {
    let expected = correctAnswers[config.accName];
    if (!expected) return; // Skip if no answer defined for this flap
    
    // 2. Get the current letter for this specific flap
    let current = GetPlayer().GetVar(config.variableName);
    let isCorrect = (current === expected);
    
    if (isCorrect) {
        passed = passed && true;
    } else {
        passed = false;
    }
});

// 3. Send data back to Storyline
GetPlayer().SetVar("SlidePassed", passed);
}

window.Script3 = function()
{
  const flapName = "SplitFlap0"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script4 = function()
{
  const flapName = "SplitFlap1"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script5 = function()
{
  const flapName = "SplitFlap2"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script6 = function()
{
  const flapName = "SplitFlap3"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script7 = function()
{
  const flapName = "SplitFlap4"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script8 = function()
{
  const flapName = "SplitFlap5"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script9 = function()
{
  const flapName = "SplitFlap6"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script10 = function()
{
  const flapName = "SplitFlap7"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script11 = function()
{
  window.flapDefaults = {
    width: 120, height: 168, radius: 4,
    colorTop: "#bab1cf", colorBot: "#7564a0", textColor: "#000000",
    fontSize: 140, fontFamily: "'IBM Plex Mono', monospace, sans-serif",
    elements: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"], initialChar: "0"
};
window.flapConfigs = [
    { accName: "SplitFlap0", variableName: "Flap0_State" },
    { accName: "SplitFlap1", variableName: "Flap1_State" },
    { accName: "SplitFlap2", variableName: "Flap2_State" },
    { accName: "SplitFlap3", variableName: "Flap3_State" },
    { accName: "SplitFlap4", variableName: "Flap4_State" },
    { accName: "SplitFlap5", variableName: "Flap5_State" },
    { accName: "SplitFlap6", variableName: "Flap6_State" },
    { accName: "SplitFlap7", variableName: "Flap7_State" }
];
window.splitFlaps = {}; 
window.flapConfigs.forEach(customConfig => {
    const config = Object.assign({}, window.flapDefaults, customConfig);
    const container = document.querySelector(`[data-acc-text="${config.accName}"]`);
    if (!container) return;
    const midY = config.height / 2;
    const seamY = midY - 2.5; 
    const svgContent = `
    <div class="split-flap-container" style="position: relative; width: 100%; height: 100%; perspective: 1000px;">
      <div class="face pt" style="position: absolute; left: 0; top: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; top:0;">
          <rect x="0" y="0" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorTop}"/>
          <text class="char-pt" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face ft" style="position: absolute; left: 0; top: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; top:0;">
          <rect x="0" y="0" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorTop}"/>
          <text class="char-ft" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face pb" style="position: absolute; left: 0; bottom: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; bottom:0;">
          <rect x="0" y="${midY}" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorBot}"/>
          <text class="char-pb" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
      <div class="face fb" style="position: absolute; left: 0; bottom: 0; width: 100%; height: 50%; overflow: hidden;">
        <svg viewBox="0 0 ${config.width} ${config.height}" width="100%" height="200%" preserveAspectRatio="xMidYMid meet" style="position:absolute; bottom:0;">
          <rect x="0" y="${midY}" width="${config.width}" height="${midY}" rx="${config.radius}" fill="${config.colorBot}"/>
          <text class="char-fb" x="${config.width/2}" y="${midY}" dy="0.35em" text-anchor="middle" font-family="${config.fontFamily}" font-weight="700" font-size="${config.fontSize}" fill="${config.textColor}"> </text>
          <rect x="0" y="${seamY}" width="${config.width}" height="5" fill="#000"/>
        </svg>
      </div>
    </div>
    `;
    container.innerHTML = svgContent;
    let startIdx = config.elements.indexOf(config.initialChar);
    if (startIdx === -1) startIdx = 0;
    
    window.splitFlaps[config.accName] = {
        config: config, currentIndex: startIdx,
        textPt: container.querySelector('.char-pt'), textPb: container.querySelector('.char-pb'),
        textFt: container.querySelector('.char-ft'), textFb: container.querySelector('.char-fb'),
        flapTopD: container.querySelector('.ft'), flapBotD: container.querySelector('.fb')
    };
    const f = window.splitFlaps[config.accName];
    gsap.set(f.flapTopD, { transformOrigin: '50% 100%', backfaceVisibility: 'hidden', rotationX: 0 });
    gsap.set(f.flapBotD, { transformOrigin: '50% 0%', backfaceVisibility: 'hidden', rotationX: 90 });
    
    let startChar = config.elements[startIdx];
    f.textPt.textContent = startChar; f.textPb.textContent = startChar;
    f.textFt.textContent = startChar; f.textFb.textContent = startChar;
    
    if (typeof GetPlayer !== "undefined") {
        GetPlayer().SetVar(config.variableName, startChar);
    }
});
}

window.Script12 = function()
{
  // 1. Define the correct answers for this specific slide!
const correctAnswers = {
    "SplitFlap0": "6",
    "SplitFlap1": "0",
    "SplitFlap2": "0",
    "SplitFlap3": "0",
    "SplitFlap4": "0",
    "SplitFlap5": "0",
    "SplitFlap6": "0",
    "SplitFlap7": "0"
};

let passed = true;

window.flapConfigs.forEach(config => {
    let expected = correctAnswers[config.accName];
    if (!expected) return; // Skip if no answer defined for this flap
    
    // 2. Get the current letter for this specific flap
    let current = GetPlayer().GetVar(config.variableName);
    let isCorrect = (current === expected);
    
    if (isCorrect) {
        passed = passed && true;
    } else {
        passed = false;
    }
});

// 3. Send data back to Storyline
GetPlayer().SetVar("SlidePassed", passed);
}

window.Script13 = function()
{
  const flapName = "SplitFlap0"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script14 = function()
{
  const flapName = "SplitFlap1"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script15 = function()
{
  const flapName = "SplitFlap2"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script16 = function()
{
  const flapName = "SplitFlap3"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script17 = function()
{
  const flapName = "SplitFlap4"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script18 = function()
{
  const flapName = "SplitFlap5"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script19 = function()
{
  const flapName = "SplitFlap6"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

window.Script20 = function()
{
  const flapName = "SplitFlap7"; 

const f = window.splitFlaps[flapName];
if(!f) return; 

gsap.killTweensOf([f.flapTopD, f.flapBotD]);

const elements = f.config.elements;
const fromC = elements[f.currentIndex];
f.currentIndex = (f.currentIndex + 1) % elements.length;
const toC = elements[f.currentIndex];

f.textPt.textContent = toC; f.textPb.textContent = fromC;  
f.textFt.textContent = fromC; f.textFb.textContent = toC;    

gsap.set(f.flapTopD, { rotationX: 0 });
gsap.set(f.flapBotD, { rotationX: 90 });
gsap.to(f.flapTopD, { rotationX: -90, duration: 0.15, ease: 'power2.in' });
gsap.to(f.flapBotD, { rotationX: 0, duration: 0.15, ease: 'power2.out', delay: 0.15 });

if (typeof GetPlayer !== "undefined") {
    GetPlayer().SetVar(f.config.variableName, toC);
}
}

};
